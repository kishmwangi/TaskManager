# TaskManager

TaskManager is a CLI application for managing tasks and categories.

## Installation

1. Clone the repository.
2. Navigate to the project directory.
3. Install dependencies using Pipenv:
    ```
    pipenv install
    ```

## Usage

Initialize the database:

Add a new category:

list all categories 

Add a new category:


List all tasks (optionally filter by category):

delet task


## Development

To develop and test the application:
1. Activate the virtual environment:
    ```
    pipenv shell
    ```

## License

MIT License